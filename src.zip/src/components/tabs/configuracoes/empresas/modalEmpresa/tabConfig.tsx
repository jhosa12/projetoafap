



export const TabConfig = () => {
    return(
        <div></div>
    )
}