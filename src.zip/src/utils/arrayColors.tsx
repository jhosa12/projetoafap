
export const arrayColors = [
    '#2a9d90',
    '#e76e50',
    '#f4a261',
    '#f1c40f',
    '#e67e22',
    '#c0392b',
    '#e8c468',
    '#8e44ad',
    '#3498db',
    '#e74c3c',
    '#2a9d90',
    '#e76e50',
    '#f4a261',
    '#f1c40f',
    '#e67e22',
    '#c0392b',
]