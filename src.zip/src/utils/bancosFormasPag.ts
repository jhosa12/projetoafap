const formasDePagamento = ["PIX", "DINHEIRO", "CARTAO CREDITO", "CARTAO DEBITO", "DEPOSITO", "BOLETO"];
const bancos = ["CORA", "BANCO DO BRASIL", "PAGBANK", "CAIXA ECONOMICA FEDERAL", "TON"];





export {formasDePagamento, bancos}