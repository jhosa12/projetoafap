






export interface FuncaoProps {
    id: string;
    descricao: string;
}