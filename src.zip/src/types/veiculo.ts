


export type VeiculoProps = {
    id_veiculo:number|null,   
    placa:string       
    marca:string          
    modelo:string        
    ano:string           
    cor:string           
    chassi:string
    status?:string       
}