export type PlanosProps = {
    id_plano: number,
    descricao: string,
    valor: number
}