export type CidadesProps = {
    id_cidade: number,
    estado: number,
    uf: string,
    cidade: string
}