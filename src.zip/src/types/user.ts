export type SignInProps = {
    user: string,
    password: string,
}

export type UserProps = {
    id: string,
    nome: string,
    cargo: string,
    dir: string,
    image: string,
}